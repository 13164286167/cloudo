<?php
//1:加载init.php 文件
require("00_init.php");
//2:获取参数
//key  商品关键字      ""
//low  商品价格下限    0
//high 商品价格上限    210000000
//pno  页码            1
//pageSize  页大小     8
@$key = $_REQUEST["key"];
@$low = $_REQUEST["low"];
@$high = $_REQUEST["high"];
@$pno = $_REQUEST["pno"];
@$pageSize = $_REQUEST["pageSize"];
//3:设置默认值
if(!$key){
  $key = "";
}
if(!$low){
  $low = 0;
}
if(!$high){
  $high = 2100000000;
}
if(!$pno){
  $pno = 1;
}
if(!$pageSize){
  $pageSize = 8;
}
//echo $key."_".$low."_".$high."_".$pno."_".$pageSize;
//4:创建sql语句  总记录数
$sql = " SELECT count(lid) as c FROM xz_laptop";
$sql .=" WHERE lname LIKE '%$key%'";
$sql .=" AND  price >= $low";
$sql .=" AND  price <= $high";
$rs = mysqli_query($conn,$sql);
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
$row = mysqli_fetch_row($rs);
$pageCount = ceil($row[0]/$pageSize);
//5:创建sql语句  当前页内容
$offset = ($pno-1)*$pageSize;
$sql =  " SELECT title,lid,lname,price ";
$sql .= " FROM xz_laptop";
$sql .= " WHERE lname LIKE '%$key%'";
$sql .= " AND price >= $low";
$sql .= " AND price <= $high";
$sql .= " LIMIT $offset,$pageSize";
$rs = mysqli_query($conn,$sql);
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
$rows = mysqli_fetch_all($rs,MYSQLI_ASSOC);
//6:将结果拼装数据转换json
$output = ["pno"=>$pno,"pageSize"=>$pageSize,
"pageCount"=>$pageCount,"data"=>$rows];
//7:发送
echo json_encode($output);