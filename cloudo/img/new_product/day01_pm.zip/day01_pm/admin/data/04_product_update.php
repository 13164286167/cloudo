<?php
//1:加载init.php
require("00_init.php");
//2:获取二个参数 lid price
@$lid = $_REQUEST["lid"];
@$price = $_REQUEST["price"];
//3:创建二个正则表达式对以上参数进行验证
$reg = '/^[0-9]{1,}$/';
$rs = preg_match($reg,$lid);
if(!$rs){
  die('{"code":-1,"msg":"商品编号格式不正确"}');
}
//100  100.50  100.3
$regprice = '/^[0-9]{1,}(\.[0-9]{1,2})?$/';
$rs = preg_match($regprice,$price);
if(!$rs){
  die('{"code":-1,"msg":"商品价格格式不正确"}');
}
//4:创建sql语句
$sql = "UPDATE xz_laptop SET price=$price WHERE lid=$lid";
//5:执行sql语句
$rs = mysqli_query($conn,$sql);
//6:判断sql语句执行中是否产生错误
if(mysqli_error($conn)){
   echo mysqli_error($conn);
}
//7:判断结果，更新是否成功
$count = mysqli_affected_rows($conn);
if($count>0){
   echo '{"code":1,"msg":"更新成功"}';
}else{
   echo '{"code":-1,"msg":"更新失败"}';
}
