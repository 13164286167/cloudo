<?php
//1:加载init.php
require("00_init.php");
//2:获取 17参数
$family_id = $_REQUEST["family_id"];
$title = $_REQUEST["title"];
$subtitle = $_REQUEST["subtitle"];
$price =$_REQUEST["price"];
$promise = $_REQUEST["promise"];
$spec = $_REQUEST["spec"];
$lname = $_REQUEST["lname"];
$os = $_REQUEST["os"];
$memory = $_REQUEST["memory"];
$resolution = $_REQUEST["resolution"];
$video_card = $_REQUEST["video_card"];
$cpu =  $_REQUEST["cpu"];
$video_memory =  $_REQUEST["video_memory"];
$category =  $_REQUEST["category"];
$disk =  $_REQUEST["disk"];
$details =  $_REQUEST["details"];
$shelf_time = time()*1000;
$sold_count = 0;
$is_onsale = 0;
//3:创建sql语句
$sql = "";
$sql .=" INSERT INTO `xz_laptop`(`lid`,";
$sql .=" `family_id`, `title`,";
$sql .=" `subtitle`, `price`,";
$sql .=" `promise`, `spec`,";
$sql .=" `lname`, `os`,";
$sql .=" `memory`, `resolution`,";
$sql .=" `video_card`, `cpu`,";
$sql .=" `video_memory`, `category`,";
$sql .=" `disk`, `details`,";
$sql .=" `shelf_time`, `sold_count`,";
$sql .=" `is_onsale`)";
$sql .=" VALUES (";
$sql .=" null,$family_id,'$title',";
$sql .=" '$subtitle',$price,'$promise',";
$sql .=" '$spec','$lname','$os',";
$sql .=" '$memory','$resolution','$video_card',";
$sql .=" '$cpu','$video_memory','$category',";
$sql .=" '$disk','$details',$shelf_time,";
$sql .=" $sold_count,$is_onsale);";
$rs = mysqli_query($conn,$sql);
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
$count = mysqli_affected_rows($conn);
if($count>0){
  echo '{"code":1,"msg":"添加成功"}';
}else{
  echo '{"code":-1,"msg":"添加失败"}';
}
//4:返回json