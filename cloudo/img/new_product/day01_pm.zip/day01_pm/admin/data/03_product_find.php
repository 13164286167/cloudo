<?php
//1:加载init.php
require("00_init.php");
//2:获取参数lid
@$lid = $_REQUEST["lid"];
//3:创建正则表达式对lid进行验证
$reg = '/^[0-9]{1,}$/';
$rs = preg_match($reg,$lid);
if(!$rs){
  die('{"code":-1,"msg":"商品编号格式不正确"}');
}
//4:创建sql
$sql = " SELECT lid,lname,price,title,os,cpu,disk,category ";
$sql .=" FROM xz_laptop WHERE lid=$lid";
//5:发送sql
$rs = mysqli_query($conn,$sql);
//6:判断发送SQL是否出错
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
$row = mysqli_fetch_assoc($rs);
//7:将查询结果转换json
$output = ["code"=>1,"data"=>$row];
echo json_encode($output);