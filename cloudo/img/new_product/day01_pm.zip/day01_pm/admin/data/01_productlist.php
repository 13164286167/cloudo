<?php
//1:加载init.php 文件
require("./00_init.php");
//2:获取参数 pno pageSize
@$pno = $_REQUEST["pno"];
@$pageSize = $_REQUEST["pageSize"];
//3:如二个参数进行判断，如果参数无效设置
//  默认值   pno=1 pageSize=8
if(!$pno){
 $pno = 1;
}
if(!$pageSize){
 $pageSize = 8;
}
//echo $pno."|".$pageSize;
//4:创建正则表达式对参数进行验证
$reg = '/^[0-9]{1,}$/';
$rs = preg_match($reg,$pno);
if(!$rs){
  die('{"code":-1,"msg":"页码格式不正确"}');
}
$rs = preg_match($reg,$pageSize);
if(!$rs){
  die('{"code":-1,"msg":"页大小格式不正确"}');
}
//5:创建sql语句查询总记录数
$sql = "SELECT count(lid) as c FROM xz_laptop";
$rs = mysqli_query($conn,$sql);
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
$row = mysqli_fetch_row($rs);
$pageCount = ceil($row[0]/$pageSize);
//6:创建sql语句查询当前页内容
$offset = ($pno-1)*$pageSize;
$sql = " SELECT lid,lname,price,title FROM xz_laptop";
$sql.= " LIMIT $offset,$pageSize";
$rs = mysqli_query($conn,$sql);
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
$rows = mysqli_fetch_all($rs,MYSQLI_ASSOC);
//7:返回结果 json
$output = ["pno"=>$pno,"pageSize"=>$pageSize,
          "pageCount"=>$pageCount,"data"=>$rows];
echo json_encode($output);