<?php
//1:加载 init.php
require("00_init.php");
//2:创建sql语句查询产品类别表
$sql = "SELECT fid,fname FROM xz_laptop_family";
//3:发送sql语句
$rs = mysqli_query($conn,$sql);
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
//4:获取所有的内容
$rows = mysqli_fetch_all($rs,MYSQLI_ASSOC);
//5:转换json
//6:输出
echo json_encode($rows);