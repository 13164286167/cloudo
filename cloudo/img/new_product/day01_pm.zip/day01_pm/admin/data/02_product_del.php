<?php
//1:加载init.php 文件
require("00_init.php");
///2:获取参数 lid
@$lid = $_REQUEST["lid"];
//3:创建正则表达式验证 lid
//4:如果验证出错，停止程序运行输出错误信息
$reg = '/^[0-9]{1,}$/';
$rs = preg_match($reg,$lid);
if(!$rs){
  die('{"code":-1,"msg":"商品编号格式不正确"}');
}
//5:创建sql语句
$sql = "DELETE FROM xz_laptop WHERE lid = $lid";
//6:发送sql语句
$rs = mysqli_query($conn,$sql);
//7:判断发送sql语句是否有误
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
//8:判断执行是否成功  UPDATE INSERT DELETE 判断条件
//  影响行数
$row = mysqli_affected_rows($conn);
//9:输出返回结果
if($row>0){
  echo '{"code":1,"msg":"删除成功"}';
}else{
  echo '{"code":-1,"msg":"删除失败"}';
}