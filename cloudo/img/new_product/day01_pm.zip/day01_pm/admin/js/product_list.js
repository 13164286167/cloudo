
//完成第一个功能模块:产品分页显示
function loadProducts(pno,pageSize){
    $("[data-action='update-ok']").data("pno",pno);
 //1:发送ajax请求
   //data/product_list.php
   //pno pageSize
 //2:获取返回数据
  $.ajax({
      type:"GET",   //请求方式
      url:"data/01_productlist.php", //请求地址
      data:{pno:pno,pageSize:pageSize},      //请求参数
     success:function(data){
       console.log(data.pno);
       console.log(data.pageSize);  //页大小8
       console.log(data.pageCount); //总页数6
       console.log(data.data);
       //1:创建字符串拼接当前页内容
       var html = "";
       for(var item of data.data){
        html += `
          <tr>
                <td>
                  <div class="checkbox" style="margin: 0;">
                    <label>
                      <input type="checkbox" class="selectedItem">
                    </label>
                  </div>
                </td>
                <td>${item.lid}</td>
                <td>${item.lname}</td>
                <td>${item.title}</td>
                <td>${item.price}</td>
                <td>
                  <a href="${item.lid}" class="btn-del">删除</a>
                  <a href="${item.lid}" class="btn-update">更新</a>
                  <a href="${item.lid}" class="btn-detail">详细信息</a>  
              </td>
              </tr>
        `;
       }
       $("#tbody1").html(html);
       //2:创建字符串拼接分页页条 [1][2][3][4]
       var pno = parseInt(data.pno);
       var pageCount = parseInt(data.pageCount);
       var html = "";
       if(pno-2>0){
        html += `<li><a href="#">${pno-2}</a></li>`;
       }
       if(pno-1>0){
        html += `<li><a href="#">${pno-1}</a></li>`;
       }
       html += `<li class="active"><a href="#">${pno}</a></li>`;
       if(pno+1<=pageCount){
       html += `<li><a href="#">${pno+1}</a></li>`;
       }
       if(pno+2<=pageCount){
       html += `<li><a href="#">${pno+2}</a></li>`;
       }
       $("#pagination").html(html);
     },
      error:function(){
          //php语法错;sql语法错;json语法错;404
          //F12->NETWORK->response
          alert("网络故障请检查..");
      }
  });
 //3:拼接字符串当前页内容
 //4:#tbody1
}
loadProducts(3,8);


//功能模块二:为分页面页码添加点击事件
//1:获取所有页码元素,并绑定点击事件 (事件代理)
$("#pagination").on("click","a",function(e){
    e.preventDefault();   //a submit button
    //2:获取当前页码
    var pno = parseInt($(this).html());
    //3:调用分页函数
    loadProducts(pno,8);
});
//全选:清空
$("#seleAll").click(function(){
    //获取当前元素状态 selected checkced
    var rs = $(this).prop("checked");
    $(".selectedItem").prop("checked",rs);
});

//1：为所有商品添加点击事件  (事件代理)
$("#tbody1").on("click",".selectedItem",function(e){
 //2：创建变量计算累加和
    var selectCount = 0;
    var totalCount = $(".selectedItem").length;
    $(".selectedItem").each((idx,item)=>{
        var rs = $(item).prop("checked");
        if(rs){
            selectCount++;
        }
    });
 //3：如果选中的个数与商品个数相同
 //4: 全选按钮  选中
   if(selectCount==totalCount) {
       $("#seleAll").prop("checked",true);
   }else{
       $("#seleAll").prop("checked",false);
   }
 //5: 如果选中的个数与商品个数不相同
 //6: 全选按钮  清空
});

//功能模块三:删除指定商品
//1:获取商品删除按钮,绑定点击事件---(事件代理)
$("#tbody1").on("click",".btn-del",function(e){
    //2:阻止事件默认行为
    e.preventDefault();
    //3:显示确认框
    var rs = window.confirm("是否删除指定的记录");
    //4:如果用户确定要删除指定商品
    console.log(1);
    if(!rs){
        return;
    }
    //5:获取商品编号
    var lid = parseInt($(this).attr("href"));
    console.log(2);
    console.log(lid);
    //6:创建正则表达式对商品编号进行验证
    var reg = /^[0-9]{1,}$/;
    //7:如果验证失败 提示出错消息
    if(!reg.test(lid)){
       alert("商品编号格式不正确，请重试");
       return;
    }
    console.log(3);
    //8:发送ajax请求
    $.ajax({
        type:"POST",     //GET:"php select"
        url:"data/02_product_del.php",
        data:{lid:lid},
        success:function(data){
            //php ->'code:1,msg:".."' jquery->js obj
            if(data.code>0){
                alert(data.msg);
                loadProducts(1,8);
            }else{
                alert(data.msg);
            }
        },
        error:function(){alert("网络故障请检查")}
    });
    //9:提示删除成功消息，并且调用分页函数显示新页数据
});


//功能模块四:更新商品价格
//  14:37~14:47
//4.1:显示需要更新商品信息
  //1:获取商品列表中更新按钮,绑定点击事件 -->(事件代理 )
  $("#tbody1").on("click",".btn-update",function(e){
      //2:阻止事件默认行为
      e.preventDefault();
      console.log(1);
      //3:获取当前商品编号
      var lid = parseInt($(this).attr("href"));
      console.log(2);
      console.log(lid);
      //4:创建正则表达大对商品编号进行验证
      var reg = /^[0-9]{1,}$/;
      if(!reg.test(lid)){
          alert("商品编号格式不正确");
          return;
      }
      //5:发送ajax请求 03_product_find.php
      $.ajax({
          type:"GET",
          url:"data/03_product_find.php",
          data:{lid:lid},
          success:function(data){
              console.log(data);
              //6:获取商品价格 商品名称 商品编号
              //7:将上述三个数据保存对话框
              var updatejumbotron= $(".update-jumbotron");
              updatejumbotron.find(".pname").html(data.data.lname);
              updatejumbotron.find(".input-price").val(data.data.price);
              updatejumbotron.find("[data-action='update-ok']").attr("href",data.data.lid);
              //8:显示商品更新对话框
              updatejumbotron.show();
          },
          error:function(){alert("网络故障，请检查")}
      });
  });

//4.2:更新价格
 //a:点击取消按钮->对话框隐藏
 $("[data-action='update-cancel']").click(function(e){
     e.preventDefault();
     $(".update-jumbotron").hide();
});
 //b:点击确定按钮
$("[data-action='update-ok']").click(function(e){
    e.preventDefault();
    //1:获取商品价格
    var price = $(".input-price").val();
    //2:获取商品编号
    var lid = parseInt($(this).attr("href"));
    console.log("#"+lid);
    //3:创建2个正则表达式对商品价格和商品编号验证
    var reg = /^[0-9]{1,}$/;
    if(!reg.test(lid)){
        alert("商品编号不正确");
        return;
    }
    var regprice = /^[0-9]{1,}(\.[0-9]{1,2})?$/;
    if(!regprice.test(price)){
       alert("商品价格不正确");
       return;
    }
    var pno = parseInt($(this).data("pno"));
    //4:发送ajax请求更新 04_product_update.php
    $.ajax({
        type:"POST",
        url:"data/04_product_update.php",
        data:{price:price,lid:lid},
        success:function(data){
            if(data.code>0){
                alert(data.msg);
                $(".update-jumbotron").hide();
                loadProducts(pno,8);
            }else{
                alert(data.msg);
            }

        },
        error:function(){alert("网络故障请检查")}
    });
    //5:更新后提示 更新成功或者更新失败消息
});

//功能模块五:商品详细信息
//1:获取商品详细信息按钮，绑定点击事件(事件代理)
$("#tbody1").on("click",".btn-detail",function(e){
    //2:阻止事件默认行为 a submit button
    e.preventDefault();
    console.log(1);
    //3:获取参数lid 商品编号
    var lid = parseInt($(this).attr("href"));
    //4:创建正则表达式验证商品编号
    var reg = /^[0-9]{1,}$/;
    if(!reg.test(lid)){
        alert("商品编号不正确");
        return;
    }
    //5:发送ajax请求 03_product_find.php
    $.ajax({
        type:"GET",
        url:"data/03_product_find.php",
        data:{lid:lid},
        success:function(data){
           var obj = data.data;
           //6:获取当前商品详细信息
           //7:添加详细信息对话框中
           var detailjumbotron = $(".detail-jumbotron");
            detailjumbotron.find(".plid").html(obj.lid);
            detailjumbotron.find(".ppname").html(obj.lname);
            detailjumbotron.find(".pcategory").html(obj.category);
            detailjumbotron.find(".pprice").html(obj.price);
            detailjumbotron.find(".pos").html(obj.os);
            detailjumbotron.find(".pdisk").html(obj.disk);
           //8:显示该对话框
            detailjumbotron.show();
        },
        error:function(){alert("网络故障，请检查")}
    });

});
//功能模块六:关闭详细信息对话框
//1:点击详细认息对话框-->{关闭}
//  关闭-》对话框隐藏













