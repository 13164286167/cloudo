/**
 * 搜索指定商品内容
 * @param pno        页码
 * @param pageSize   页大小
 * @param low        价格下限
 * @param high       价格上限
 * @param key        商品关键字
 */
function searchProduct(pno,pageSize,low,high,key){
   //1:如果网络繁忙，网页会出现空白状态,显示进度条
   $("#tbody1").html(`
      <div class="loading">
           <img src="img/loading.gif" alt="..."/>
      </div>
   `);
   //2:发送ajax请求获取当前页数据
   $.ajax({
       type:"GET",
       url:"data/07_product_search.php",
       data:{pno,pageSize,low,high,key},
       success:function(data){
           //console.log(data);
           //3:创建当前页内容
           var html = "";
           var rows = data.data;
           for(var item of rows){
               html +=`
  <tr>
                <td>
                  <div class="checkbox" style="margin: 0;">
                    <label>
                      <input type="checkbox">
                    </label>
                  </div>
                </td>
                <td>${item.lid}</td>
                <td>图片</td>
                <td>型号</td>
                <td>${item.title}</td>
                <td>${item.lname}</td>
                <td>${item.price}</td>
                <thd>  </thd>
              </tr>             
               `;
           }
           $("#tbody1").html(html);
           //4:创建分页条 [1][2][3][4][5]
           var pno = parseInt(data.pno);
           var pageCount = parseInt(data.pageCount);
           var html = "";
           if(pno-2>0) {
               html += `<li><a href="#">${pno-2}</a></li>`;
           }
           if(pno-1>0) {
               html += `<li><a href="#">${pno-1}</a></li>`;
           }
           html += `<li class="active"><a href="#">${pno}</a></li>`;
           if(pno+1<=pageCount) {
               html += `<li><a href="#">${pno+1}</a></li>`;
           }
           if(pno+2<=pageCount) {
               html += `<li><a href="#">${pno+2}</a></li>`;
           }
           $("#pagination").html(html);
       },
       error:function(){
           alert("网络故障请检查!!!")
       }
   });

}
searchProduct(1,8,0,21000000,"");


//功能模块二:为价格上限绑定键盘事件
$("#product-high").keyup(function(e){
    //获取价格上限，下限，关键字
    var key = $("#product-kw").val();
    var low = $("#product-low").val();
    var high = $(this).val();
    //如果用户输入回车键
    if(13 == e.keyCode){
        searchProduct(1,8,low,high,key);
    }

});




