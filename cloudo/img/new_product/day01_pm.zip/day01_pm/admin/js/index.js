//js/index.js
//功能:完成后台管理员登录
//1:获取登录按钮 #btn
//2:为按钮绑定点击事件
//3:阻止事件默认行为  绑定元素 a;submit;
$("#btn").click(function(e){
    e.preventDefault();
    console.log(1);
   //4:获取用户输入值 用户名 密码
   var uname = $("#uname").val();
   var upwd = $("#upwd").val();
   var yzm = $("#yzm").val();
   var yzmreg = /^[a-z]{4}$/i;
   if(!yzmreg.test(yzm)){
       alert("验证码格式不正确");
       return;
   }
   //5:创建正则表达式验证用户输入 用户名和密码
   var reg = /^[a-z0-9]{3,12}$/i;
   if(!reg.test(uname)){
       alert("用户名格式不正确");
       return;
   }
   if(!reg.test(upwd)){
       alert("密码格式不正确");
       return;
   }
   console.log(2);
   console.log(uname+"_"+upwd);
   //6:如果验证出错显示错误信息
   //7:发送ajax data/01_admin_login.php
   //8:获取返回结果
   $.ajax({
      type:"GET",    //请求方式: GET/POST
      url:"data/01_admin_login.php",         //请求路径
      data:{uname:uname,upwd:upwd,yzm:yzm},       //发送时参数
      success:function(data){
          //data     php返回结果 json 字符串->jquery->js object
          //data = {code:1,msg:"登录成功"}
          //console.log(data);
          if(data.code>0){
             alert(data.msg);
             location.href = "main.html";
          }else{
             alert(data.msg);
          }


      },
      error:function(){
       //请求地址错误 404,sql语句错误,json拼接,php语法错
       alert("网络故障请检查!")}
   });
   // code>0 登录成功跳转 main.html页面
   //9:获取返回结果错误  提示错误信息
});
