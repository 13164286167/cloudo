    ///1:创建商品类别列表
    console.log(1);
    $.ajax({
        type:"GET",
        url:"data/06_product_family_list.php",
        success:function(data){
           var html = "<option value='1'>--请选择--</option>";
           for(var item of data){
               html += `
               <option value="${item.fid}">${item.fname}</option>
               `;
           }
           $("#family_id").html(html);
        },
        error:function(){
            alert("网络故障请检查!!!!");
        }
     });

    //1:为添加按钮绑定点击事件
    $("#btn1").click(function(){
        //2:获取所有参数创建正则表达式验证
        //3:表单序列化 title=...
        var data = $("#form-product").serialize();
        //4:发送ajax
        $.ajax({
            type:"POST",
            url:"data/05_product_add.php",
            data:data,
            success:function(data){
                if(data.code>0){
                    alert(data.msg);
                }else{
                    alert(data.msg);
                }
            },
            error:function(){alert("网络故障请检查")}
        });
    });
