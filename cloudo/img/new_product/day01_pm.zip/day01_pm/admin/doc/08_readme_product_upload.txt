功能模块七:上传商品图片
完成此功能需要程序
问题:
(1):上传图片保存
   admin/upload/product/sm  小图    54*54
   admin/upload/product/md  中图    450*450
   admin/upload/product/lg  大图    800*800
   admin/upload/product/bs  原始大小
(2):数据库表 xz_laptop_pic
   pid/laptop_id/sm/md/lg
1:data/12_product_upload.php
2:product_list.html
3:js/product_list.js

