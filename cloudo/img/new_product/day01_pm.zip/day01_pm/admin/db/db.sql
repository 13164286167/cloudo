--1:设计表
--库名/表名/列名  全小写
--? 几张表  1张
--? 表名    xz_admin
--? 表几列  uid[整型 主键] uname upwd
--? 类型
--  uid   INT PRIMARY KEY
--  uname VARCHAR(25)
--  upwd  VARCHAR(32)  密码加密保留md5()->32位
--  19901010                               原文
--  a65b11fd9599516a9c190e21f72b830e       密文
--  md5(md5("19901010"));
--  用户:8位以[大写字母,小写小字,数字]
--? 添加几行数据
CREATE TABLE xz_admin(
  uid   INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(25),
  upwd  VARCHAR(32)
);
INSERT INTO xz_admin VALUES(null,'james',md5('123'));
INSERT INTO xz_admin VALUES(null,'tom',md5('123'));
INSERT INTO xz_admin VALUES(null,'jerry',md5('123'));