//游戏入口程序
//1:挂载index.html文件中
//2:声明游戏中使用变量
//2.1:创建二个变量保存画布
var can1;
var can2;
//2.2:创建二个变量保存画笔
var ctx1;
var ctx2;
//2.3:创建一个变量保存背景图片
var bgPic = new Image();
//2.4:创建二个变量保存画布宽度和高度
var canWidth = 0;
var canHeight = 0;
//2.5:创建一个变量保存海葵对象
var ane;
//2.6:创建一个变量保存食物对象
var fruit;
///2.7:创建二个变量保存上一帧执行时间和二帧间隔时间差
var lastTime;
var deltaTime;

//3:创建函数game-->启动函数
function game(){
    init();
    lastTime = Date.now();  //上一帧时间
    deltaTime = 0;
    gameloop();
}
//4:创建函数init,初始化函数，初始化变量和对象值
function init(){
    //4.1 初始二个画布
    can1 = document.getElementById("canvas1");
    can2 = document.getElementById("canvas2");
    //4.2:初始二个画笔
    ctx1 = can1.getContext("2d");
    ctx2 = can2.getContext("2d");
    //4.3:下载背景图片
    bgPic.src = "src/background.jpg";
    //4.4:初始画布宽度和高度
    canWidth = can1.width;
    canHeight = can1.height;
    //console.log(bgPic);
    //console.log(canWidth+"_"+canHeight);
    //4.5：创建海葵对象并且调用初始化方法
    ane = new aneObj();
    ane.init();
    //4.6: 创建食物对象并且调用初始化方法
    fruit = new fruitObj();
    fruit.init();
}
//5:创建函数gameloop  通过智能定时器调用绘制游戏中不同角色功能
function gameloop(){
    //5.1 创建智能定时器调用 gameloop
    requestAnimFrame(gameloop);
    //5.11 二帧之间时间差
    var now = Date.now();        //当前时间
    deltaTime = now - lastTime; //二帧之差
    lastTime = now;              //更新上一帧时间
    if(deltaTime>40){
        deltaTime = 40;
    }
    //console.log(deltaTime);

    //5.2:绘制背景图片
    drawBackground();
    //5.3:监听画布上的食物数量
    fruitMonitor();
    //5.8:绘制海葵
    ane.draw();
    //5.9:绘制食物
    fruit.draw();

}
//6:页面加载成功后调用game函数
document.body.onload =  game;

